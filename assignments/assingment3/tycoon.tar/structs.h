#ifndef STRUCTS_H
#define STRUCTS_H
#include <iostream>
#include <cstdlib>
#include <cmath>
#include <ctime>

using namespace std;

struct citizens{
	int agreeability;
	int monthlyBudget;
};

struct busPeople{
	int agreeability;
	int monthlyBudget;
};

#endif